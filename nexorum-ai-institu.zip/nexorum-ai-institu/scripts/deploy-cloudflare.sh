#!/bin/bash
set -e

echo "Deploying Cloudflare Workers..."

cd cloudflare/workers/api-gateway
npm install
npx wrangler deploy --env production

echo "API Gateway deployed to Cloudflare Edge!"
echo ""
echo "Deploying Cloudflare Pages..."
cd ../../pages
# Build frontend first
cd ../../frontend
npm install
npm run build
cd ../cloudflare/pages
npx wrangler pages deploy ../../frontend/dist --project-name nexorum-frontend

echo "Frontend deployed to Cloudflare Pages!"
