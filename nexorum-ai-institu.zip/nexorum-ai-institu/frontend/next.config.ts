import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  reactStrictMode: true,
  images: { unoptimized: true },
  async rewrites() {
    return [
      { source: '/api/v1/:path*', destination: 'http://localhost:8080/api/v1/:path*' },
      { source: '/ws/:path*', destination: 'http://localhost:8005/ws/:path*' }
    ];
  }
};

export default nextConfig;
