# NEXORUM AI — Cloud Deployment Guide

## Cloudflare Pages (Frontend) — Step by Step

### Step 1: Push code to GitHub

```bash
git init
git add .
git commit -m "NEXORUM init"
git remote add origin https://github.com/YOUR_USER/nexorum.git
git push -u origin main
```

### Step 2: Connect in Cloudflare Dashboard

1. Go to **Cloudflare Dashboard → Pages**
2. Click **"Create a project"**
3. Click **"Connect to Git"**
4. Select your GitHub repository
5. Click **"Begin setup"**

### Step 3: Build Settings (CRITICAL!)

On the setup page, find **"Build settings"** section:

| Setting | Value |
|---------|-------|
| **Framework preset** | **`None`** |
| **Build command** | `cd frontend && npm install && npm run build` |
| **Build output directory** | `frontend/dist` |
| **Root directory** | `/` |

**IMPORTANT:** Do NOT select "Next.js" in Framework preset! Leave it as "None".

### Step 4: Environment Variables

Add these in the same setup page:

| Variable | Value |
|----------|-------|
| `NODE_VERSION` | `20` |

### Step 5: Save and Deploy

Click **"Save and Deploy"**

---

## Troubleshooting

### Error: `/bin/sh: 1: Next.js: not found`

**Cause:** Framework preset is set to "Next.js" instead of "None"

**Fix:**
1. Dashboard → Pages → Your project → Settings → Builds & deployments
2. Change **Framework preset** to `None`
3. Set **Build command** to: `cd frontend && npm install && npm run build`
4. Set **Build output directory** to: `frontend/dist`
5. Click **Save**
6. Go to Deployments → Click **"Retry deployment"** on the latest failed build

### Error: `Could not read package.json`

**Cause:** `package.json` is not in the repository root

**Fix:** Make sure `package.json` exists in the root of your repo (not in a subfolder). Check with:
```bash
git ls-files | grep "^package.json"
```

### Error: `Build output not found`

**Cause:** Next.js is not generating static files to `frontend/dist`

**Fix:** Check `frontend/next.config.ts` contains:
```ts
output: 'export',
distDir: 'dist',
```

---

## Cloudflare Worker (API Gateway)

Deployed automatically via GitHub Actions.

Add secrets to GitHub:
- `CLOUDFLARE_API_TOKEN`
- `CLOUDFLARE_ACCOUNT_ID`

---

## Kubernetes (Hetzner)

See `scripts/deploy-k8s.sh` and `terraform/` directory.

## GitHub Secrets

| Secret | How to get |
|--------|-----------|
| `CLOUDFLARE_API_TOKEN` | Dashboard → My Profile → API Tokens → Create Token (Use template: "Edit Cloudflare Workers") |
| `CLOUDFLARE_ACCOUNT_ID` | Dashboard → any page → right sidebar |
| `KUBECONFIG` | `cat ~/.kube/config | base64` |
