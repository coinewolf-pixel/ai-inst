# NEXORUM AI — Cloud Deployment Guide

## Cloudflare Pages Setup (Frontend)

### Option A: GitHub Actions (Рекомендуется)

Добавьте секреты в GitHub Repository → Settings → Secrets:
- `CLOUDFLARE_API_TOKEN`
- `CLOUDFLARE_ACCOUNT_ID`

Push в `main` — frontend автоматически задеплоится.

### Option B: Cloudflare Dashboard (Git Integration)

1. **Dashboard → Pages → Create Project → Connect Git**

2. **Build settings** (ВАЖНО — выберите "None"):

| Поле | Значение |
|------|----------|
| **Framework preset** | **`None`** |
| **Build command** | `cd frontend && npm install && npm run build` |
| **Build output directory** | `frontend/dist` |
| **Root directory** | `/` |

3. **Environment variables**:
   - `NODE_VERSION` = `20`

⚠️ **НЕ выбирайте Framework preset "Next.js"!** Cloudflare Pages для Next.js требует `@cloudflare/next-on-pages`, что сломает билд. Используйте static export (`output: 'export'` в next.config.ts).

---

## Troubleshooting

### `/bin/sh: 1: Next.js: not found`
→ Вы выбрали Framework preset "Next.js" в Dashboard. **Смените на "None"** и укажите Build Command вручную.

### `Could not read package.json`
→ Проверьте что `package.json` в корне репозитория. Распакуйте ZIP так, чтобы файлы были прямо в корне, без подпапки `nexorum-ai-institu/`.

### `Build output not found`
→ Проверьте `frontend/next.config.ts` содержит `output: 'export'` и `distDir: 'dist'`.
