#!/bin/bash
set -e

echo "╔════════════════════════════════════════════════════════════╗"
echo "║     NEXORUM — Cloudflare Edge Deployment                   ║"
echo "╚════════════════════════════════════════════════════════════╝"

# ── 1. Deploy API Gateway (Cloudflare Worker) ──────────────
echo "[1/3] Deploying API Gateway Worker..."
cd cloudflare/workers/api-gateway
npm install
npx wrangler deploy
cd ../../..

# ── 2. Build Frontend for static export ──────────────────────
echo "[2/3] Building Next.js frontend (static export)..."
cd frontend
npm install
npm run build
cd ..

# ── 3. Deploy to Cloudflare Pages ────────────────────────────
echo "[3/3] Deploying frontend to Cloudflare Pages..."
cd cloudflare/pages
npm install
npx wrangler pages deploy ../../frontend/dist   --project-name nexorum-frontend   --branch main   --commit-hash $(git rev-parse HEAD 2>/dev/null || echo "manual")
cd ../..

echo ""
echo "✅ Cloudflare deployment complete!"
echo "   API Gateway: https://nexorum-api-gateway.your-subdomain.workers.dev"
echo "   Frontend:    https://nexorum-frontend.pages.dev"
