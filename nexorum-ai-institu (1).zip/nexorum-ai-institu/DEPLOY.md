# NEXORUM AI — Cloud Deployment Guide

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    CLOUDFLARE EDGE                           │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │   Pages     │  │  Workers    │  │   DNS + CDN + WAF   │  │
│  │  (Next.js)  │  │  (API GW)   │  │   (DDoS, RateLimit) │  │
│  └──────┬──────┘  └──────┬──────┘  └─────────────────────┘  │
│         │                │                                   │
│         └────────────────┘                                   │
└────────────────────────┬────────────────────────────────────┘
                         │ HTTPS
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                 HETZNER CLOUD (EU)                         │
│  ┌─────────────────────────────────────────────────────┐  │
│  │              Kubernetes (k3s) Cluster                │  │
│  │  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌──────────┐ │  │
│  │  │Control  │ │ Worker1 │ │ Worker2 │ │  Worker3 │ │  │
│  │  │(Ingress) │ │(DB+AI)  │ │(Risk+CH)│ │(Exchange)│ │  │
│  │  └────┬────┘ └────┬────┘ └────┬────┘ └────┬─────┘ │  │
│  │       └───────────┴───────────┴───────────┘       │  │
│  │                                                      │  │
│  │  Services: AI-Orchestrator ×2  │  Exchange ×3        │  │
│  │            Risk-Engine ×2    │  Auth ×2            │  │
│  │            Market-Data ×2    │  Frontend ×2        │  │
│  └─────────────────────────────────────────────────────┘  │
│                                                            │
│  Volumes:  Postgres 50GB  │  ClickHouse 100GB             │
│                                                            │
└─────────────────────────────────────────────────────────────┘
```

## Quick Deploy (Production)

### Prerequisites
- Hetzner Cloud account + API token
- Cloudflare account + API token (Zone:Edit, Page Rules:Edit)
- Domain configured in Cloudflare
- Docker Hub or GHCR registry access
- `kubectl`, `helm`, `terraform`, `wrangler` CLI installed

### Step 1: Infrastructure (Terraform)
```bash
cd terraform
cp terraform.tfvars.example terraform.tfvars
# Edit terraform.tfvars with your tokens
./scripts/deploy-terraform.sh
```

### Step 2: Kubernetes Setup
SSH into the control node Terraform created:
```bash
ssh root@$(terraform output -raw k8s_control_ip)
./scripts/setup-k3s.sh
```

Copy kubeconfig to local:
```bash
scp root@<control-ip>:/etc/rancher/k3s/k3s.yaml ~/.kube/nexorum-config
export KUBECONFIG=~/.kube/nexorum-config
```

### Step 3: Build & Push Images
```bash
export DOCKER_REGISTRY=ghcr.io/nexorum
export VERSION=$(git rev-parse --short HEAD)
./scripts/build-and-push.sh
```

### Step 4: Deploy to K8s
```bash
export KUBE_CONTEXT=nexorum-prod
./scripts/deploy-k8s.sh
```

### Step 5: Cloudflare Edge
```bash
export CLOUDFLARE_API_TOKEN=your-token
./scripts/deploy-cloudflare.sh
```

## Cost Estimate (Monthly)

| Component | Provider | Spec | Cost |
|-----------|----------|------|------|
| Control Node | Hetzner | CX41 (4vCPU/16GB) | ~€15 |
| Worker 1 | Hetzner | CPX41 (8vCPU/32GB) | ~€30 |
| Worker 2 | Hetzner | CPX41 (8vCPU/32GB) | ~€30 |
| Volumes | Hetzner | 150GB total | ~€7 |
| Cloudflare Pro | Cloudflare | CDN + WAF | ~€20 |
| **Total** | | | **~€102/mo** |

## Monitoring Stack (Optional)

Deploy Prometheus + Grafana:
```bash
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm install prometheus prometheus-community/kube-prometheus-stack   --namespace monitoring --create-namespace
```

Access Grafana: `kubectl port-forward svc/prometheus-grafana 3000:80 -n monitoring`
Default login: `admin` / `prom-operator`

## Scaling

```bash
# Scale specific service
kubectl scale deployment nexorum-exchange-connector --replicas=10 -n nexorum

# Or update Helm values
helm upgrade nexorum ./helm/nexorum --set services.exchangeConnector.replicaCount=10
```
