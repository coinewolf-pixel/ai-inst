# NEXORUM — Cloudflare Pages (HTML Version)

This is a 100% working static HTML/CSS/JS dashboard for Cloudflare Pages.
No build step. No frameworks. Just upload and it works.

## Deploy (30 seconds)

### Option 1: Git Integration
1. Push this folder to GitHub
2. Cloudflare Dashboard → Pages → Create Project → Connect Git
3. Framework preset: `None`
4. Build command: (leave empty)
5. Build output directory: `/`
6. Save and Deploy

### Option 2: Direct Upload
1. Zip this folder
2. Cloudflare Dashboard → Pages → Create Project → Direct Upload
3. Upload the ZIP
4. Done

## Features
- Responsive dark trading dashboard
- Real-time canvas chart
- Glassmorphism UI
- Animated stats cards
- Agent monitoring
- Risk visualization
- Zero dependencies (Tailwind via CDN)
