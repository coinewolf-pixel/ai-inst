# NEXORUM AI — Cloud Deployment Guide

## Cloudflare Pages Setup (Frontend)

### Option A: GitHub Actions (Рекомендуется)

Просто добавьте секреты и push в main:
```bash
git add .
git commit -m "deploy"
git push origin main
```

### Option B: Cloudflare Dashboard (Git Integration)

1. **Dashboard → Pages → Create Project → Connect Git**

2. **Build settings**:

| Поле | Значение |
|------|----------|
| Framework preset | `Next.js` |
| Build command | `npm run build` |
| Build output directory | `frontend/dist` |
| Root directory | `/` |

3. **Environment variables**:
   - `NODE_VERSION` = `20`

⚠️ **ВАЖНО**: Не указывайте `npx wrangler deploy` или `wrangler pages deploy` в Build Command! Cloudflare Pages сам деплоит после успешного билда.

## Структура репозитория

```
/
├── package.json              # Корневой (для Pages если root=/)
├── frontend/
│   ├── package.json          # Frontend deps
│   ├── next.config.ts        # output: 'export', distDir: 'dist'
│   └── dist/                 # Build output (static files)
├── backend/                  # Microservices
├── cloudflare/
│   └── workers/
│       └── api-gateway/      # Worker (wrangler deploy)
└── .github/workflows/
    ├── deploy-pages.yml      # Pages via GH Actions
    ├── deploy-worker.yml     # Worker via GH Actions
    └── deploy-k8s.yml        # Kubernetes via GH Actions
```

## GitHub Secrets

| Secret | Где взять |
|--------|----------|
| `CLOUDFLARE_API_TOKEN` | Dashboard → My Profile → API Tokens → Create Token |
| `CLOUDFLARE_ACCOUNT_ID` | Dashboard → правый сайдбар |
| `KUBECONFIG` | `cat ~/.kube/config | base64` |

## Troubleshooting

### "Could not read package.json"
→ Убедитесь что `package.json` запушен в репозиторий. Проверьте: `git ls-files | grep package.json`

### "No such file or directory"
→ Проверьте Root directory в настройках Pages. Если указано `/`, `package.json` должен быть в корне.

### "Build output not found"
→ Проверьте что `frontend/next.config.ts` содержит `output: 'export'` и `distDir: 'dist'`.
